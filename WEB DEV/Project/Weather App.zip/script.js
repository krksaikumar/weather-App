const app = document.querySelector('.app')
const searchButton = document.querySelector('.search')
const searchModule = document.querySelector('.search-module')
const inputValue = document.querySelector('[input-city]')
const searchCity = document.querySelector('#search')
const slider = document.querySelector('.slider')
const sliderActive = document.querySelector('.slider.active')
const forecast = document.querySelector('.forecast')
const temperature = document.querySelector('.temperature')
const cityName = document.querySelector('.city-name')
const wrapper = document.querySelector('.wrapper')
const condition = document.querySelector('.condition')
const error = document.querySelector('.error')
const maxTemp = document.querySelector('.max-temp')
const minTemp = document.querySelector('.min-temp')
const text = document.querySelector('.text')
const icon = document.querySelector('.icon')
const table = document.querySelector('.hour-forecast')
const key = '84695518c95b4ccb8a732922211002'
// const img = document.querySelector('.img')
// let city = 'tenali'

// sunlogo =' //cdn.weatherapi.com/weather/64x64/day/113.png'
// moonlogo = "//cdn.weatherapi.com/weather/64x64/night/116.png"

window.addEventListener('load', byCoords())

searchButton.addEventListener('click', ()=>{
    searchModule.classList.add('active')
})
searchCity.addEventListener('click', ()=>{
    let city = inputValue.value
    searchModule.classList.remove('active')
    byName(city);
})
slider.addEventListener('click', ()=>{
    if(forecast.classList.value == 'forecast active'){
        forecast.classList.remove('active')
        app.style.overflow = 'hidden';
    }
    // position: fixed
    else{
        forecast.classList.add('active')
        app.style.overflow = 'scroll';
    }
})

function byCoords(){
    let lat, long, api1, api2
    // const proxy = 'https://cors-anywhere.herokuapp.com/'
    // let api = `http://api.weatherstack.com/current?access_key=${key}&query=${lat},${long}`
    // const key = '80e9d5701efe84fffed651c3e5773ba4'
    // const key = '84695518c95b4ccb8a732922211002'
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(position=>{
            lat = position.coords.latitude
            long = position.coords.longitude
            console.log(lat, long)
            api1 = `http://api.weatherapi.com/v1/current.json?key=${key}&q=${lat},${long}`
            api2 = `http://api.weatherapi.com/v1/forecast.json?key=${key}&q=${lat},${long}`
            fetchApi(api1)
            setForecast(api2)
        })
    }
}

function byName(name){
    let api1 = `http://api.weatherapi.com/v1/current.json?key=${key}&q=${name}`
    let api2 = `http://api.weatherapi.com/v1/forecast.json?key=${key}&q=${name}`
    fetchApi(api1) 
    setForecast(api2)
}

function fetchApi(api){
    fetch(api)
    .then(response=>response.json())
    .then(data=>{
        if(data.error){
            if(error.classList.value == 'error active'){
                error.classList.remove('active')
            }else{
                error.classList.add('active')
            }
        }
        else{ 
            // console.log(data)
            if(document.querySelector('.img') != null) document.querySelector('.img').remove()
            temperature.innerHTML = data.current.temp_c+'&deg;c'
            cityName.innerHTML = data.location.name
            condition.innerHTML = data.current.condition.text
            let img = document.createElement('img')
            img.src = data.current.condition.icon
            img.className = 'img'
            wrapper.appendChild(img)
            
            // logo.setAttribute('src', data.current.condition.icon)
            return false
        }
    })
}

function setForecast(api){
    fetch(api)
    .then(response=>response.json())
    .then(data=>{
        console.log(data)
        let castObject = data.forecast.forecastday[0].day
        maxTemp.innerHTML = 'max: '+castObject.maxtemp_c +'&deg;'
        minTemp.innerHTML = 'min: '+castObject.mintemp_c+'&deg;'
        text.innerHTML = castObject.condition.text
        icon.src = castObject.condition.icon    
        
        table.querySelectorAll('tr').forEach(tr=>{
            tr.remove()
        })
        let tr = document.createElement('tr'),
            time = document.createElement('th'),
            temp = document.createElement('th'),
            condition = document.createElement('th'),
            icon1 = document.createElement('th')
        time.innerHTML = 'Time'
        temp.innerHTML = 'Temp'
        icon1.innerHTML = 'Icon'
        condition.innerHTML = 'Condition'
        tr.appendChild(time)
        tr.appendChild(temp)
        tr.appendChild(condition)
        tr.appendChild(icon1)
        table.appendChild(tr)
        
        let object = data.forecast.forecastday[0].hour
        for(let i=0; i<24; i+=1){
            let tr = document.createElement('tr')
            let time = document.createElement('td'),
            temp = document.createElement('td'),
            condition = document.createElement('td'),
            icon = document.createElement('td'),
            img = document.createElement('img')
            img.src = object[i].condition.icon
            time.innerHTML = object[i].time
            temp.innerHTML = object[i].temp_c
            condition.innerHTML = object[i].condition.text
            icon.appendChild(img) 
            tr.appendChild(time)
            tr.appendChild(temp)
            tr.appendChild(condition)
            tr.appendChild(icon)
            table.appendChild(tr)
        }
    })
}